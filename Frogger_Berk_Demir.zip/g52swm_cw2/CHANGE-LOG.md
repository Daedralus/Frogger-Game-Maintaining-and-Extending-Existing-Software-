THIS DOCUMENT WAS ORIGINALLY NAMED README AS A WAY TO DOCUMENT WORK PROGRESS OVER EACH COMMIT

1 - All frogger files moved into src, java and resources separated into their respectful folders.
2 - Version control added via git. ".gitignore" added to ignore ".gradle" and ".idea"
3 - All unused code cleaned up
    - in "Turtle.java" & "WetTurtle.java" removed unused "int i" and "bool bool"
    - in "Actor.java" removed unused methods "getWidth", "getHeight", "manageInput", "getOneIntersectingObject"
    - in "Animal.java" removed unused "int bounds"
    - in "MyStage.java" removed unused method "MyStage" (contents completely commented)
    - in "Digit.java" removed unused "int dim"
    - in "Main.java" removed commented out code and unused imports
    - in "World.java" removed unused imports and "remove" method
4 - Understanding of existing code:
    - Javadoc added to methods that were understood or given early thoughts
    - Comments added for clarification on old code before refactoring
    - Comments also added for thoughts/guesses/notes for future aid but will be removed
    - Methods and variables made private where implied. All files affected.


5 - Refactoring done:
    - General: Scope of variables not globally used switched to local as should be
    - General: Javadocs added to all methods in any class. 

    - in "Animal.java"
        - All movement related image variables converted to more meaningful name
        - 'w' replaced with progressScoreCheck as new and more understandable name
        - if statements for car deaths and water deaths reduced to increase efficiency
        - Respawn 'if' statement adjusted to become the 'else' statement to increase efficiency
        - Moved 'second = false' outside 'else if' chain to avoid repetitious code

    - in "Main.java"
        - Added proper background rather than non-existent screen shot
        - Converted ugly chain of addition/subtraction to final number
        - Each element added to scene now has its own function for readability
        - in "setNumber", variable names changed to more readable ones.

    - To Resources:
        - "iKogsKW.png" resized and recolored to match "End.png" using GIMP
        - All turtle images also background color matched with "End.png" GIMP
        - "iKogsKW.png" deleted with "background.png" now acting as background
        - "background.png" edited to have high score and current score displayed.
        - Old "background.png" converted to "menu.png" to act as menu screen. Frogger title also centered.

    - in "End.java"
        - matched the size of "End.png" and "FrogEnd.png"

6 - New Features:
    - in "Main.java"
        - Menu page added with "PLAY" and "RULES" button
            - Play button starts the game
            - Rules pop-up as an alert when pressed (may get own scene later)
        - Game window now has "Frogger" as title
        - Added music for main menu & game: Credits: "Arcade.mp3" by Trevor Lentz licensed CC BY-SA 3.0: https://opengameart.org/sites/default/files/Arcade_0.mp3
            - Copyright information: https://creativecommons.org/licenses/by-sa/3.0/
        - Added "createLifeCount" and "updateLifeCount" methods that creates the life count and updates the life count respectively
        - "createTimer" method adjusted to include new check for updates on life counter
        - Added "Jingle_Achievement_01.mp3" sound effect on victory: Credits: "Jingle_Achievement_01.mp3" by Little Robot Sound Factory licensed CC-BY 3.0 https://opengameart.org/content/8-bit-sound-effects-library
                    - Copyright information: http://creativecommons.org/licenses/by/3.0/legalcode
                    - website of author: www.littlerobotsoundfactory.com
        - Added "getHighScore" method that can read the top line of "highscore.dat" which is then displayed on game scene
          via setNumber method with appropriate xpos and ypos.
        - Added "checkScore" and "saveScore" methods. "checkScore" can check and see if new high score set and flag true for new boolean "highScoreGame" which then
          sets the current score as the high score. "saveScore" simply opens a JOptionPanel asking for the player's name and saves the name and score
          to "highscore.dat" in "player-score" format.
        - Added victory scene for when game is completed successfully with high-score and current game score present very similarly to game over screen
        - New highscore gif and a gif of the frog jumping in position added to make the victory screen more lively.
        - New addition to "getHighScore" method that also saves the top 7 scores into topSeven string array variable.
        - New method called "displayHighScores" that handles the VBox and Text for the score scene for display
        - Completed working implementation of high score page on main menu with top 7 scores displayed.

    - in "MyStage.java" (renamed to MyMedia.java)
        - Renamed for more accurate name and to avoid confusion with JavaFX Stage
        - added methods playDeath, playGameOVer, playProgress, playVictory for new sound effects

    - in "Animal.java"
        - Added new deaths variable that counts deaths. Once it reaches 3, new method "gameOver" is triggered, ending the game.
        - Added death sound to play on death: Credits: "explosion.wav" by Rodeo licensed CC BY 3.0: https://opengameart.org/sites/default/files/blasteroids-sfx_0.zip
            - Profile of author: https://opengameart.org/users/rodeo
            - Copyright information: https://creativecommons.org/licenses/by/3.0/
        - Added "gameOver" and "updateLife" methods that check if lives are zero for a game over case and updates lives respectively
        - Added "Collect_Point_01" sound effect on reaching any end slot: Credits: "Collect_Point_01.mp3" by Little Robot Sound Factory licensed CC-BY 3.0 https://opengameart.org/content/8-bit-sound-effects-library
            - Copyright information: http://creativecommons.org/licenses/by/3.0/legalcode
            - website of author: www.littlerobotsoundfactory.com
        - Added "Jingle_Lose_00.mp3" sound effect on game over: Credits: "Jingle_Lose_00.mp3" by Little Robot Sound Factory licensed CC-BY 3.0 https://opengameart.org/content/8-bit-sound-effects-library
                    - Copyright information: http://creativecommons.org/licenses/by/3.0/legalcode
                    - website of author: www.littlerobotsoundfactory.com
        - Added "nextLevel" method to check if all 5 slots are full to then proceed to next level

    - Added new "GameButtons.java" class
        - Previous button images swapped with arcade text versions
    - Added new "Life.java" class
        - Very similar to all other elements in game, creates the frog life counter for the scene.
    - in "End.java"
        - Moved activated = false into "End" method to be able to create more in second level

7 - Bug-fixing/refactoring new features
    - in "Animal.java"
        - converted method "gameOver" into boolean type.
        - changed "getStop" method to check for end == 10 instead of 5
        - changed the life-check to happen later so lives and score is updated on screen first

    - in "Main.java"
        - Added new trigger for when "gameOver" returns true in "Animal.java"
        - Play and Rules button now have setPickOnBounds(true) to allow clicks on transparent area
        - Play and Rules button images cropped to avoid excess clickable region
        - Changed method "setNumber" to have xpos and ypos parameters to have different scoreboards
        - Rules now have their own scene rather than a simple boring alert with a back button to the menu page.
        - Ensured that highscores are read from file at start of program to avoid reading it while null
        - Fixed bug that caused highscore to not appear in game scene.
        - Adjusted victory check to happen at 10 slots and to start new level at 5

    - in "AdapterImage.java"
        - Renamed from "FactoryImage.java" and refactored for the entire code. Noticed that the design pattern was not
          actually returning an object like the factory design pattern should do, therefore changed to Adapter design
          pattern to be correct.

    - in "World.java"
        - added "remove" method to be able to remove actors as well.

8 - Cleanup for new additions
    - Ultimately unused variables and methods removed from Main.java and Animal.java
    - Comments and Javadocs revised for all new additions
    - Missed cleanup on "start" method in "Main.java" now done for creating scoreboard.
    - Comments made for "createMenupage" and "creaTimer" methods in "Main.java"
    - Comments made for rule page creation as well as splitting the code to more readable chunks
    - Cleaned up unused code, alert message of old rule implementation removed.
    - Comments and unnecessary variables removed from high-score implementation from "Main.java" and "Animal.java".
    - "restart" method removed. No longer used alert imports also removed.
    - Cleanup done for highscores page implementation. Unused images deleted, image names improved and made unique.
    - Javadoc param's updated for new classes
    - Gotten rid of system.out.print's for debugging from highscore implementation
    - Renamed "CREDITS.TXT" to "LICENCES.TXT"
    - New condition that checks for null on name entry
    - Removed unecessary imports, variables, if statements, methods, comments across multiple classes
    - Fixed javadocs across multiple classes
