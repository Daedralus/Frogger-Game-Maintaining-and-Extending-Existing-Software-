Please view in file to see list format properly - 483 words

Tested on:
- Lab machine: Use IntelliJ and simply import (select main class and module while importing) and run!
- Windows 10:  Java jdk1.8.0_221, JavaFX 13
- Build Script: Gradle

Refactoring done to existing code (Applies to all where not stated):
- All files packaged in a correct format under created "src/main/java/froggerGame" and "src/main/resources"
- Large cleanup was performed to get rid of any unused method, variable, commented-out code, imports etc. for cleaner code
- Scopes and access of methods/variables changed where needed, Main broken down to many sub-methods and any new Object group given their own class to ensure encapsulation.
- Variables and methods renamed into more understandable ones for readability
- If statements in Main.java and Animal.java simplified where possible for efficiency

New Features:
- Many new backgrounds, buttons and adjustments made using GIMP for smoother game experience
    - Backgrounds: Menu, Rules, Scores, Victory and Game Over screens all are made via GIMP by editing original "iKogsKW.png" file
    - Game buttons and all text uses custom font called "Press Start 2P" (see "LICENCES.md" for citation) for a more immersive game
- Game loop music replaced with a better one, and many new sound effects have been implemented for a more immersive experience (see "LICENCES.md" for citations)
- Menu page that has 3 image buttons, "PLAY", "RULES" and "SCORES", each with their own scene. These buttons also have their own new Class called "GameButton"
    - PLAY: Starts the game
    - RULES: Shows rules page
    - SCORES: Shows top-scores page with highest 7 scores
- New Game Over (on lose) and Victory (on win) screens that replace the dull alert in a much more immersive way.
- New AdapterImage Class that follows the Adapter Design Pattern to generate any one-off object into the game without having to create a new class for all of them
- High-score system implemented that displays the top 7 in "SCORES" page that reads from file "highscore.dat". This file can be infinitely long
- All game scores (win or lose) are written to "highscore.dat" alongside with your name as a bonus to see who actually got the top scores!
- New "Life" class that handles the life counter at the bottom left of screen. "Animal.java" now also follows how many lives you have (default 3) and you lose when they hit zero!
- New "CrocodileBody" and "CrocodileHead" classes the handle crocodiles. Bodies are safe like logs but if you jump on the head, you get eaten!
- New level added once first 5 ends are filled. Second level replaces 3 logs with crocodiles for more gameplay and challenge. Max score is 1600 as a result!
- All classes and methods added to Javadocs for documentation

Extras:
See "CHANGE-LOG.md" for more detailed version of the above
See "LICENCES.TXT" for citations
See "Appendix" file for extra information/graphics including screenshot of every scene