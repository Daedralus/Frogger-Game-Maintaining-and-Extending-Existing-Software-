package froggerGame;

import static org.junit.Assert.*;

import org.junit.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;
import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.scene.text.Text;

import javax.swing.*;
import java.io.*;
import java.util.ArrayList;

public class MainTest {
        //Unfortunately out of time for tests! But could have definitely done a lot more with
        //another 2 days. I was on the road for 3 days and unable to work an additional day.
        //Then started working on new level + video + diagram which took the rest of the extension time
        //Still, there are plenty of new features and I am quite proud of the game regardless!

        @Test
        public void testHighestScore() {
                Main main = new Main();
                main.getHighScore();

                assertEquals(Integer.parseInt(main.topSeven[0].split("-")[1]), main.highScoreInt);
        }

        @Test
        public void testHighScoreGame(){
                Main main = new Main();
                main.getHighScore();

                main.checkScore(99999);
                assertTrue(main.highScoreGame);
        }

        @Test
        public void testNotHighScoreGame(){
                Main main = new Main();
                main.getHighScore();

                main.checkScore(0);
                assertFalse(main.highScoreGame);
        }

}