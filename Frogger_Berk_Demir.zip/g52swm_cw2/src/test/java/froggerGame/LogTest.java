package froggerGame;

import org.junit.Test;
import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.scene.text.Text;

import javax.swing.*;
import java.io.*;
import java.util.ArrayList;

import static org.junit.Assert.*;

public class LogTest {


    @Test
    public void testLogCreation(){

        Log log = new Log("file:src/main/resources/log3.png", 150, 0, 166, 0.75);
        assertNotNull(log);
    }
}