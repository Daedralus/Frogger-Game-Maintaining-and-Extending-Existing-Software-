package froggerGame;

import static org.junit.Assert.*;

public class ActorTest {
    //MainTest has tests!
}