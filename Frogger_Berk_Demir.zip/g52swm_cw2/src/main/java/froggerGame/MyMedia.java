package froggerGame;

import java.io.File;

import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

/**
 * Handles all the media for the game
 */
public class MyMedia extends World{
	private MediaPlayer mediaPlayer;

	@Override
	public void act(long now) {
		
	}
	/**
	 * Function that gets the path to the music file to then play it
	 */
	void playMusic() {
		String musicFile = "src/main/resources/Arcade.mp3";
		Media sound = new Media(new File(musicFile).toURI().toString());
		mediaPlayer = new MediaPlayer(sound);
		mediaPlayer.setCycleCount(MediaPlayer.INDEFINITE);
	    mediaPlayer.play();
	}

	/**
	 * Function that gets the path to the death sound file to then play it
	 */
	void playDeath(){
		String deathFile = "src/main/resources/explosion.wav";
		Media sound = new Media(new File(deathFile).toURI().toString());
		MediaPlayer deathPlayer = new MediaPlayer(sound);
		deathPlayer.play();
	}

	/**
	 * Function that gets the path to the game over sound file to then play it
	 */
	void playGameOver(){
		String menuFile = "src/main/resources/Jingle_Lose_00.mp3";
		Media sound = new Media(new File(menuFile).toURI().toString());
		MediaPlayer gameOverPlayer = new MediaPlayer(sound);
		gameOverPlayer.play();
	}

	/**
	 * Function that gets the path to the collect point sound file to then play it
	 */
	void playProgress(){
		String menuFile = "src/main/resources/Collect_Point_01.mp3";
		Media progress = new Media(new File(menuFile).toURI().toString());
		MediaPlayer progressPlayer = new MediaPlayer(progress);
		progressPlayer.play();
	}

	/**
	 * Function that gets the path to the victory sound file to then play it
	 */
	void playVictory(){
		String menuFile = "src/main/resources/Jingle_Achievement_01.mp3";
		Media progress = new Media(new File(menuFile).toURI().toString());
		MediaPlayer victoryPlayer = new MediaPlayer(progress);
		victoryPlayer.play();
	}

	/**
	 * Function to stop playing music
	 */
	void stopMusic() {
		mediaPlayer.stop();
	}

}
