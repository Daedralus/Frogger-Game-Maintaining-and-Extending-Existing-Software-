package froggerGame;

import javafx.scene.image.Image;

/**
 * CrocodileBody class that handles all the crocodiles safe to land bodies
 */

public class CrocodileBody extends Actor {

    private double speed;


    @Override
    public void act(long now) {
        move(speed , 0);
        if (getX()>600 && speed>0)
            setX(-180);
        if (getX()<-300 && speed<0)
            setX(700);
    }

    /**
     * Method to animate the logs
     * @param imageLink image link of log
     * @param width size of log to appear in game
     * @param height size of log to appear in game
     * @param xpos x coordinate the log appears
     * @param ypos y coordinate the log appears
     * @param s speed of the log?
     */
    CrocodileBody(String imageLink, int width, int height, int xpos, int ypos, double s) {
        setImage(new Image(imageLink, width,height, true, true));
        setX(xpos);
        setY(ypos);
        speed = s;
    }
}
