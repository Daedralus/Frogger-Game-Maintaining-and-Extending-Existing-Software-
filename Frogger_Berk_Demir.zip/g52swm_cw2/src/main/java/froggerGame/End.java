package froggerGame;

import javafx.scene.image.Image;

/**
 * End class that handles the end slots which the frog aims to reach
 */
public class End extends Actor{

	private boolean activated;

	@Override
	public void act(long now) {
		// TODO Auto-generated method st
	}


	/**
	 * Function that sets the five end goal coordinates
	 * @param x width
	 * @param y height
	 */
	End(int x, int y) {
		setX(x);
		setY(y);
		setImage(new Image("file:src/main/resources/End.png", 60, 60, true, true));
		activated = false;
	}

	/**
	 * Function that replaces the empty end goal with one with a frog instead
	 * Goals with a frog is then set as activated.
	 */
	void setEnd() {
		setImage(new Image("file:src/main/resources/FrogEnd.png", 60, 60, true, true));
		activated = true;
	}

	/**
	 * Function that sets slots as "activated" if frog successfully enters it.
	 * @return true if frog reaches slot, false otherwise.
	 */
	boolean isActivated() {
		return activated;
	}
	

}
