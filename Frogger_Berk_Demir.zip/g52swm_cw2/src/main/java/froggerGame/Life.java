package froggerGame;

import javafx.scene.image.Image;

/**
 * Life class that handles the lives of the frog
 */
public class Life extends Actor{
    @Override
    public void act(long now) {
        // TODO Auto-generated method stub

    }

    /**
     * Method to add frog image to bottom left of screen as visual for life count. Takes x and y coordinate
     * as well as dimensions in order to create in correct location and in correct size.
     * @param xpos x coordinate of image to place
     * @param ypos y coordinate of image to place
     * @param width width of the image
     * @param height height of the image
     */
    Life(int xpos, int ypos, int width, int height){
        Image lifeFrog = new Image("file:src/main/resources/froggerUp.png", width, height, true, true);
        setImage(lifeFrog);
        setX(xpos);
        setY(ypos);
    }
}
