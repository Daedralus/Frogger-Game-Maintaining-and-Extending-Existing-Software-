package froggerGame;

import javafx.scene.image.Image;

/**
 * Digit class that handles all the counters in the game (life, score and high-scores)
 */
public class Digit extends Actor{
	@Override
	public void act(long now) {
		// TODO Auto-generated method stub
		
	}
	/**
	 * Method to add image of digit between 0-9 determined via setNumber or hard-coded placement
	 * @param n determines which number from 0 to 9 to be added
	 * @param dim dimension of image
	 * @param x x coordinate of placement
	 * @param y y coordinate of placement
	 */
	Digit(int n, int dim, int x, int y) {

		Image im1 = new Image("file:src/main/resources/"+n+".png", dim, dim, true, true);
		setImage(im1);
		setX(x);
		setY(y);
	}
	
}
