package froggerGame;

import javafx.scene.image.Image;

/**
 * Class that handles all the turtles that are not submerged
 */
public class Turtle extends Actor{
	private Image turtle1;
	private Image turtle2;
	private Image turtle3;
	private int speed;

	@Override
	public void act(long now) {
	//Weird way of determining what the turtle looks like if the module of now is a certain value. At least
	//the connected 3 turtles spawn with synced animations
				if (now/900000000  % 3 ==0) {
					setImage(turtle2);
					
				}
				else if (now/900000000 % 3 == 1) {
					setImage(turtle1);
					
				}
				else if (now/900000000 %3 == 2) {
					setImage(turtle3);
					
				}
			
		move(speed , 0);
		if (getX() > 600 && speed>0)
			setX(-200);
		if (getX() < -75 && speed<0)
			setX(600);
	}
	/**
	 * Method for turtle creation and animation
	 * @param xpos x coordinate of turtle
	 * @param ypos y coordinate of turtle
	 * @param s speed of turtle
	 * @param w width of turtle
	 * @param h height of turtle
	 */
	Turtle(int xpos, int ypos, int s, int w, int h) {
		turtle1 = new Image("file:src/main/resources/TurtleAnimation1.png", w, h, true, true);
		turtle2 = new Image("file:src/main/resources/TurtleAnimation2.png", w, h, true, true);
		turtle3 = new Image("file:src/main/resources/TurtleAnimation3.png", w, h, true, true);
		setX(xpos);
		setY(ypos);
		speed = s;
		setImage(turtle2);
	}
}
