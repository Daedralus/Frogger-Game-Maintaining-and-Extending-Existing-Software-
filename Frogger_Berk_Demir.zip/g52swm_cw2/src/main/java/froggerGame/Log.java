package froggerGame;

import javafx.scene.image.Image;

/**
 * Log class that handles all the logs
 */
public class Log extends Actor {

	private double speed;


	@Override
	public void act(long now) {
		move(speed , 0);
		if (getX()>600 && speed>0)
			setX(-180);
		if (getX()<-300 && speed<0)
			setX(700);
	}

	/**
	 * Method to add and animate the logs
	 * @param imageLink image link of log
	 * @param size size of log to appear in game
	 * @param xpos x coordinate the log appears
	 * @param ypos y coordinate the log appears
	 * @param s speed of the log?
	 */
	Log(String imageLink, int size, int xpos, int ypos, double s) {
		setImage(new Image(imageLink, size,size, true, true));
		setX(xpos);
		setY(ypos);
		speed = s;
		
	}
	boolean getLeft() {
		return speed < 0;
	}
}
