package froggerGame;

import javafx.scene.image.ImageView;


import java.util.ArrayList;

/**
 * Actor class which handles movement and finding of instances of any actor (object) added to the
 * world (stage)
 */
public abstract class Actor extends ImageView{

    /**
     * Function that determines new location after any 'move' either via water transport or key-press
     * @param dx difference of current x and desired x
     * @param dy difference of current y and desired y
     */
    void move(double dx, double dy) {
        setX(getX() + dx);
        setY(getY() + dy);
    }

    /**
     * Function to get the world
     * @return the game's world
     */
    private World getWorld() {
        return (World) getParent();
    }

    /**
     * Method to find all intersecting instances at a certain area
     * @param cls class of intersection
     * @param <A> type (class)
     * @return array of intersecting actors of given class-type
     */
    <A extends Actor> java.util.List<A> getIntersectingObjects(java.lang.Class<A> cls){
        ArrayList<A> someArray = new ArrayList<A>();
        for (A actor: getWorld().getObjects(cls)) {
            if (actor != this && actor.intersects(this.getBoundsInLocal())) {
                someArray.add(actor);
            }
        }
        return someArray;
    }

    public abstract void act(long now);

}
