package froggerGame;

import javafx.scene.image.Image;

/**
 * GameButton class that handle all the game buttons on the menu page
 */
public class GameButton extends Actor {

    @Override
    public void act(long now) {


    }

    /**
     * Method to create game button images.
     * @param imageLink image location to add desired image
     */
    GameButton(String imageLink) {
        setImage(new Image(imageLink, 250, 150, true, true));

    }
}
