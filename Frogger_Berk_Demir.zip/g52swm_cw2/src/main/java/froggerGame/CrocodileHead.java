package froggerGame;

import javafx.scene.image.Image;

/**
 * CrocodileHead Class that handles all the crocodile heads
 */
public class CrocodileHead extends Actor {

    private double speed;

    @Override
    public void act(long now) {
        move(speed , 0);
        if (getX()>600 && speed>0)
            setX(-180);
        if (getX()<-300 && speed<0)
            setX(700);
    }

    /**
     * Method to animate the crocodiles head
     * @param imageLink image link of crocodile head
     * @param width size of crocodile head to appear in game
     * @param height size of crocodile head to appear in game
     * @param xpos x coordinate the crocodile head appears
     * @param ypos y coordinate the crocodile head appears
     * @param s speed of the crocodile head
     */
    CrocodileHead(String imageLink, int width, int height, int xpos, int ypos, double s) {
        setImage(new Image(imageLink, width,height, true, true));
        setX(xpos+139);
        setY(ypos);
        speed = s;
    }

}
