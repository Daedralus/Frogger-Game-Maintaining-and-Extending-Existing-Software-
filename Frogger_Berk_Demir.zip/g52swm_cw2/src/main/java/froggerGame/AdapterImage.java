package froggerGame;

import javafx.scene.image.Image;

/**
 * AdapterImage Design Pattern Class that handles any one-off to be added to the game world. Although
 * most of the already existing classes can also be created from this class, this design pattern is used
 * to avoid having many one-off classes (and therefore many files)
 */
public class AdapterImage extends Actor {

    @Override
    public void act(long now) {


    }

    /**
     * Adapter design pattern method to create new image to scene with desired width and height sizes. This design
     * pattern avoids the need for creating a new class for every single different image needed, and allows the
     * combination of unrelated objects together.
     * @param imageLink path to desired image
     * @param width width of desired image
     * @param height height of desired image
     * @param xpos x coordinate of where the desired image will be placed
     * @param ypos y coordinate of where the desired image will be placed
     */
    AdapterImage(String imageLink, int width, int height, int xpos, int ypos) {
        setX(xpos);
        setY(ypos);
        setImage(new Image(imageLink, width, height, true, true));
    }
}
