package froggerGame;

import javafx.scene.image.Image;

/**
 * Class that handles all the turtles that are sinking
 */
public class WetTurtle extends Actor{
	private Image turtle1;
	private Image turtle2;
	private Image turtle3;
	private Image turtle4;
	private int speed;

	private boolean sunk = false;
	@Override
	public void act(long now) {
	//Weird way of determining what the turtle looks like if the module of now is a certain value. Results
	//in multiple turtle groups to sink at same time in a observable pattern (as in the same sinking pattern
	//continues throughout the entire game rather than randomized)
				if (now/900000000  % 4 ==0) {
					setImage(turtle2);
					sunk = false;
					
				}
				else if (now/900000000 % 4 == 1) {
					setImage(turtle1);
					sunk = false;
				}
				else if (now/900000000 %4 == 2) {
					setImage(turtle3);
					sunk = false;
				} else if (now/900000000 %4 == 3) {
					setImage(turtle4);
					sunk = true;
				}
			
		move(speed , 0);
		if (getX() > 600 && speed>0)
			setX(-200);
		if (getX() < -75 && speed<0)
			setX(600);
	}
	/**
	 * Method for wet turtle creation and animation
	 * @param xpos x coordinate of wet turtle
	 * @param ypos y coordinate of wet turtle
	 * @param s speed of wet turtle
	 * @param w width of wet turtle
	 * @param h height of wet turtle
	 */
	WetTurtle(int xpos, int ypos, int s, int w, int h) {
		turtle1 = new Image("file:src/main/resources/TurtleAnimation1.png", w, h, true, true);
		turtle2 = new Image("file:src/main/resources/TurtleAnimation2Wet.png", w, h, true, true);
		turtle3 = new Image("file:src/main/resources/TurtleAnimation3Wet.png", w, h, true, true);
		turtle4 = new Image("file:src/main/resources/TurtleAnimation4Wet.png", w, h, true, true);
		setX(xpos);
		setY(ypos);
		speed = s;
		setImage(turtle2);
	}

	/**
	 * Method that returns if turtle is sunk or not
	 * @return true of sunk, false otherwise
	 */
	boolean isSunk() {
		return sunk;
	}
}
