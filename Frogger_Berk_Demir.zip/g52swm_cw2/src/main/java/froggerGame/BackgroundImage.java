package froggerGame;

import javafx.scene.image.Image;

/**
 * Class to generate background images for the scenes
 */
public class BackgroundImage extends Actor{

	@Override
	public void act(long now) {
		
		
	}

	/**
	 * Creates the Background image with the given dimensions when called correctly
	 * @param imageLink image link for background image
	 */
	BackgroundImage(String imageLink) {
		setImage(new Image(imageLink, 600, 850, true, true));
		
	}

}
