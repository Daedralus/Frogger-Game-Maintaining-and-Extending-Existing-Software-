package froggerGame;

import javafx.scene.image.Image;

/**
 * Handles all the different obstacles on land (cars only for now but potentially snakes too!)
 */
public class Obstacle extends Actor {
	private int speed;


	@Override
	public void act(long now) {
		move(speed , 0);
		if (getX() > 600 && speed>0)
			setX(-200);
		if (getX() < -50 && speed<0)
			setX(600);
	}
	/**
	 * Via definition in Main.java, these are the attributes for cars and trucks
	 * @param imageLink link of car/truck
	 * @param xpos x coordinate of car/truck
	 * @param ypos y coordinate of car/truck
	 * @param s speed of vehicle
	 * @param w width of vehicle
	 * @param h height of vehicle
	 */
	Obstacle(String imageLink, int xpos, int ypos, int s, int w, int h) {
		setImage(new Image(imageLink, w,h, true, true));
		setX(xpos);
		setY(ypos);
		speed = s;
	}

}
