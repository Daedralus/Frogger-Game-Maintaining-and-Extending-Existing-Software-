package froggerGame;

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.scene.text.Text;

import javax.swing.*;
import java.io.*;
import java.util.ArrayList;


/**
 * Main class for this JavaFX program that calls start on launch by default. Handles the entire game
 * and most of the logic in an almost singleton like pattern (but is not).
 */
public class Main extends Application {
	private AnimationTimer timer;
	private MyMedia background;
	private Animal animal;
	boolean highScoreGame = false;
	int highScoreInt = 0;
	private int level = 0;
	String[] topSeven = new String[7];

	public static void main(String[] args) {
		launch(args);
	}


	/**
	 * JavaFX start function that runs when the program runs by default.
	 * @param primaryStage the stage the game uses which scenes can be added to
	 */
	@Override
	public void start(Stage primaryStage) {
		background = new MyMedia();

		//Displays the high-score at the high-score tab in game after retrieving form file
		getHighScore();

		//Create all respective elements required for the game
		createMenuPage(primaryStage);
		createBackground();
		createTurtles();
		createLogs();
		createEndSlots();
		createAnimal();
		createCars();
		createLifeCount();
		createScoreBoard();
		setNumber(highScoreInt, 150, 50);

		//'Starts' the game once all the initial elements are in position (above)
		background.start();
		start();
	}


	/**
	 * Function that adds the turtles at the start of the game. Each element is created
	 * by adding the resource file to the scene at their appropriate coordinate in-game.
	 */
	private void createBackground(){
		BackgroundImage froggerBack = new BackgroundImage("file:src/main/resources/background.png");
		background.add(froggerBack);
	}

	/**
	 * Function that adds the turtles at the start of the game. Each element is created
	 * by adding the resource file to the scene at their appropriate coordinate in-game.
	 */
	private void createTurtles(){
		background.add(new Turtle(500, 376, -1, 130, 130));
		background.add(new Turtle(300, 376, -1, 130, 130));
		background.add(new WetTurtle(700, 376, -1, 130, 130));
		background.add(new WetTurtle(600, 217, -1, 130, 130));
		background.add(new WetTurtle(400, 217, -1, 130, 130));
		background.add(new WetTurtle(200, 217, -1, 130, 130));
	}

	/**
	 * Function that adds the logs at the start of the game. Each element is created
	 * by adding the resource file to the scene at their appropriate coordinate in-game.
	 */
	private void createLogs(){
		background.add(new Log("file:src/main/resources/log3.png", 150, 0, 166, 0.75));
		background.add(new Log("file:src/main/resources/log3.png", 150, 220, 166, 0.75));
		background.add(new Log("file:src/main/resources/log3.png", 150, 440, 166, 0.75));
		background.add(new Log("file:src/main/resources/logs.png", 300, 0, 276, -2));
		background.add(new Log("file:src/main/resources/logs.png", 300, 400, 276, -2));
		background.add(new Log("file:src/main/resources/log3.png", 150, 50, 329, 0.75));
		background.add(new Log("file:src/main/resources/log3.png", 150, 270, 329, 0.75));
		background.add(new Log("file:src/main/resources/log3.png", 150, 490, 329, 0.75));
	}

	/**
	 * Function that adds the goal slots at the start of the game. Each element is created
	 * by adding the resource file to the scene at their appropriate coordinate in-game.
	 */
	private void createEndSlots(){
		background.add(new End(11,102));
		background.add(new End(139,102));
		background.add(new End(266,102));
		background.add(new End(394,102));
		background.add(new End(522,102));
	}

	/**
	 * Function that adds the frog at the start of the game. Each element is created
	 * by adding the resource file to the scene at their appropriate coordinate in-game.
	 */
	private void createAnimal(){
		animal = new Animal("file:src/main/resources/froggerUp.png");
		background.add(animal);
	}

	/**
	 * Function that adds all the cars and trucks at the start of the game. Each element is created
	 * by adding the resource file to the scene at their appropriate coordinate in-game.
	 */
	private void createCars(){
		background.add(new Obstacle("file:src/main/resources/truck1"+"Right.png", 0, 649, 1, 120, 120));
		background.add(new Obstacle("file:src/main/resources/truck1"+"Right.png", 300, 649, 1, 120, 120));
		background.add(new Obstacle("file:src/main/resources/truck1"+"Right.png", 600, 649, 1, 120, 120));
		background.add(new Obstacle("file:src/main/resources/car1Left.png", 100, 597, -1, 50, 50));
		background.add(new Obstacle("file:src/main/resources/car1Left.png", 250, 597, -1, 50, 50));
		background.add(new Obstacle("file:src/main/resources/car1Left.png", 400, 597, -1, 50, 50));
		background.add(new Obstacle("file:src/main/resources/car1Left.png", 550, 597, -1, 50, 50));
		background.add(new Obstacle("file:src/main/resources/truck2Right.png", 0, 540, 1, 200, 200));
		background.add(new Obstacle("file:src/main/resources/truck2Right.png", 500, 540, 1, 200, 200));
		background.add(new Obstacle("file:src/main/resources/car1Left.png", 500, 490, -5, 50, 50));
	}

	/**
	 * Function that creates the initial score board at the top right of the game screen
	 */
	private void createScoreBoard(){
		background.add(new Digit(0, 30, 515, 50));
		background.add(new Digit(0, 30, 485, 50));
		background.add(new Digit(0, 30, 455, 50));
		background.add(new Digit(0, 30, 425, 50));
		background.add(new Digit(0, 30, 150, 50));
		background.add(new Digit(0, 30, 120, 50));
		background.add(new Digit(0, 30, 90, 50));
		background.add(new Digit(0, 30, 60, 50));
	}

	/**
	 * Function that creates the score board at the game over screen
	 */
	private void createDeathBoard(){
		background.add(new Digit(0, 30, 330, 625));
		background.add(new Digit(0, 30, 300, 625));
		background.add(new Digit(0, 30, 270, 625));
		background.add(new Digit(0, 30, 240, 625));
		background.add(new Digit(0, 30, 330, 500));
		background.add(new Digit(0, 30, 300, 500));
		background.add(new Digit(0, 30, 270, 500));
		background.add(new Digit(0, 30, 240, 500));
	}


	/**
	 * Function that creates the logs and crocs for the second level
	 */
	private void createLevelTwo(){
		background.add(new CrocodileBody("file:src/main/resources/crocodile-body.png", 140,52,  0, 166, 0.75));
		background.add(new CrocodileHead("file:src/main/resources/crocodile-head.png", 56,52,  0, 166, 0.75));
		background.add(new Log("file:src/main/resources/log3.png", 150, 220, 166, 0.75));
		background.add(new CrocodileBody("file:src/main/resources/crocodile-body.png", 140, 52,440, 166, 0.75));
		background.add(new CrocodileHead("file:src/main/resources/crocodile-head.png", 56, 52,440, 166, 0.75));
		background.add(new Log("file:src/main/resources/logs.png", 300, 0, 276, -2));
		background.add(new Log("file:src/main/resources/logs.png", 300, 400, 276, -2));
		background.add(new CrocodileBody("file:src/main/resources/crocodile-body.png", 140,52 , 50, 329, 0.75));
		background.add(new CrocodileHead("file:src/main/resources/crocodile-head.png", 56,52 , 50, 329, 0.75));
		background.add(new Log("file:src/main/resources/log3.png", 150, 270, 329, 0.75));
		background.add(new Log("file:src/main/resources/log3.png", 150, 490, 329, 0.75));
	}

	/**
	 * Method to create timer as well as handle the end game alerts.
	 */
	private void createTimer() {

        timer = new AnimationTimer() {
            @Override
            public void handle(long now) {
            	//If update flag is true, update life count
            	if(animal.updateLife()){
            		updateLifeCount();
				}
            	//If game over flag is true, end game and switch scenes
            	if (animal.gameOver()){
					background.add(new BackgroundImage("file:src/main/resources/game-over.png"));
					background.stop();
					createDeathBoard();
					checkScore(animal.getPoints());
					//If game is a high-score game, display flashing high-score gif.
					if(highScoreGame){
						background.add(new AdapterImage("file:src/main/resources/highscore.gif", 500, 40, 50, 50));
					}
					setNumber(animal.getPoints(), 330, 625);
					setNumber(highScoreInt, 330, 500);
					saveScore(animal.getPoints());

					background.stopMusic();
					background.playGameOver();
				}
            	//If change score flag is true, update score
            	if (animal.changeScore()) {
            		setNumber(animal.getPoints(), 515, 50);
            	}
            	//If first round won, proceed to next round
				if(animal.nextLevel() && level == 0){
					level++;
					levelTwo();

				}
            	//If game won, end game and display player score with highest score possible.
            	if (animal.getStop()) {
					background.add(new BackgroundImage("file:src/main/resources/victory.png"));
					background.add(new AdapterImage("file:src/main/resources/froggerJump.gif", 80,80, 260, 300));
					checkScore(animal.getPoints());
					//If game is a high-score game, display flashing high-score gif.
					if(highScoreGame){
						background.add(new AdapterImage("file:src/main/resources/win-highscore.gif", 500, 40, 50, 50));
					}
            		createDeathBoard();
					setNumber(animal.getPoints(), 330, 625);
					setNumber(highScoreInt, 330, 500);
					saveScore(animal.getPoints());

            		background.stopMusic();
            		stop();
            		background.stop();
					background.playVictory();
            	}
            }
        };
    }

	/**
	 * Method to remove previous end slots and logs to then re-create level two version. Also brings frog to front
	 */
	private void levelTwo(){
		//Get all instances of Logs and End slots, remove them, and re-create them in new format
		ArrayList<End> slots = (ArrayList<End>) background.getObjects(End.class);
		for (End slot : slots) {
			background.remove(slot);
		}
		ArrayList<Log> logs = (ArrayList<Log>) background.getObjects(Log.class);
		for (Log log : logs) {
			background.remove(log);
		}
		createLevelTwo();
		createEndSlots();

		//Bring frog to front of scene so newer objects do not overlap it
		ArrayList<Animal> frog = (ArrayList<Animal>) background.getObjects(Animal.class);
		for (Animal animal1 : frog) {
			animal1.toFront();
		}
	}

	/**
	 * Method to create life counter on the bottom left of the screen. Simply creates "froggerUp.png"
	 * and correct number png resource at location. Maximum life count is 9, but even that is too high.
	 */
	private void createLifeCount(){
		background.add(new Life(10,750,40,40));
		Animal lives = new Animal("file:src/main/resources/froggerUp.png");
		background.add(new Digit(lives.LIVES, 30, 50, 750));
	}

	/**
	 * Method to update life counter. Simply overwrites previous image with new life count.
	 */
	private void updateLifeCount(){
			background.add(new Digit(animal.lives, 30, 50, 750));
	}


	/**
	 * The start function that sets the start of the game in action. Music starts playing and a
	 * timer is created and started.
	 */
	private void start() {
		background.playMusic();
    	createTimer();
        timer.start();
    }

	/**
	 * Method to stop the timer
	 */
 	public void stop() {
        timer.stop();
    }



	/**
	 * Method to handle score points. Shift allows new multiples of 10s via pushing the
	 * new digit image 30 pixels back. While loops handles score by dividing it by 10 to then
	 * print as single digit until last digit becomes 0 as it is an int.
	 * @param score player score updated while playing
	 * @param xpos x coordinate of where score goes
	 * @param ypos y coordinate of where score goes
	 */
	private void setNumber(int score, int xpos, int ypos) {
    	int shift = 0;
    	while (score > 0) {
    		  int next = score / 10;
    		  int digit = score - next * 10;
    		  score = next;
    		  background.add(new Digit(digit, 30, xpos - shift, ypos));
    		  shift+=30;
    		}
    }

	/**
	 * Function to create the main menu page. Utilizes the creation of an additional scene and a new border
	 * pane to create new layout with alignment control. A stack pane is created within this scene so that
	 * the buttons and background image can stack. The buttons are contained in a vertical box so that
	 * they do not overlap yet hold the exact same alignment with given gap. The buttons are then given
	 * onclick events where play switches scene to the game and rules open an alert with the rules.
	 * @param primaryStage the JavaFX stage the game runs on
	 */
	private void createMenuPage(Stage primaryStage){
		Scene scene = new Scene(background,600,800);

		//Rule scene border pane to place new objects
		BorderPane rulez = new BorderPane();
		Scene rulesPage = new Scene(rulez, 600,800);
		//Pane to space back button
		Pane spacer = new Pane();
		Pane spacer2 = new Pane();
		//StackPane used to have button and background stacked
		StackPane ruleStack = new StackPane();
		ruleStack.setAlignment(Pos.CENTER);
		//VBox to position the back button
		VBox backBtn = new VBox();


		//Background and button image
		BackgroundImage ruleArt = new BackgroundImage("file:src/main/resources/rule-page.png");
		GameButton back = new GameButton("file:src/main/resources/back.png");
		GameButton back2 = new GameButton("file:src/main/resources/back.png");
		//Button clickable even in transparent area, VBox positions and spacing adjustments
		back.setPickOnBounds(true);
		back2.setPickOnBounds(true);
		backBtn.setAlignment(Pos.CENTER_RIGHT);
		backBtn.getChildren().add(spacer);
		backBtn.getChildren().add(back);
		backBtn.setSpacing(550);
		//Finally, VBox added to stack and stack centered on scene
		ruleStack.getChildren().add(ruleArt);
		ruleStack.getChildren().add(backBtn);
		rulez.setCenter(ruleStack);

		//Border pane created to place new objects
		BorderPane scorePane = new BorderPane();
		Scene scorez = new Scene(scorePane, 600, 800);

		//Stack pane created to have objects that overlap
		StackPane scoreStack = new StackPane();
		scoreStack.setAlignment(Pos.CENTER);

		//Vertical box created to have objects that do not overlap, but remain in same
		//vertical alignment.
		VBox scoreBox = new VBox();
		VBox topScores = new VBox();

		//Call method to fill topScores VBox with top 7 high scores.
		displayHighScores(topScores);

		scoreBox.setSpacing(550);
		scoreBox.setAlignment(Pos.CENTER_RIGHT);
		scoreBox.getChildren().add(spacer2);
		scoreBox.getChildren().add(back2);

		//
		BackgroundImage scoreBoard = new BackgroundImage("file:src/main/resources/scoreboard.png");
		scoreStack.getChildren().add(scoreBoard);
		scoreStack.getChildren().add(topScores);
		scoreStack.getChildren().add(scoreBox);
		//scoreStack.getChildren().add(backBtn);
		scorePane.setCenter(scoreStack);

		//Border pane created to place new objects
		BorderPane layout = new BorderPane();
		Scene menu = new Scene(layout, 600, 800);

		//Stack pane created to have objects that overlap
		StackPane stack = new StackPane();
		stack.setAlignment(Pos.CENTER);

		//Vertical box created to have objects that do not overlap, but remain in same
		//vertical alignment.
		VBox vbox = new VBox();
		vbox.setSpacing(200);
		vbox.setAlignment(Pos.CENTER);

		VBox split = new VBox();
		split.setSpacing(10);
		split.setAlignment(Pos.BOTTOM_CENTER);

		//Menu background
		BackgroundImage menuArt = new BackgroundImage("file:src/main/resources/menu.png");
		primaryStage.setTitle("Frogger");

		//Play and Rules button created with boundaries set to true for clicking
		GameButton play = new GameButton("file:src/main/resources/play2.png");
		play.setPickOnBounds(true);
		GameButton rules = new GameButton("file:src/main/resources/rules.png");
		rules.setPickOnBounds(true);
		GameButton scores = new GameButton("file:src/main/resources/scores.png");
		scores.setPickOnBounds(true);
		GameButton blank = new GameButton("file:src/main/resources/black.png");
		blank.setPickOnBounds(true);

		//VBox added to StackPane which is then added to BorderPane
		vbox.getChildren().add(play);
		split.getChildren().add(rules);
		split.getChildren().add(blank);
		split.getChildren().add(scores);
		vbox.getChildren().add(split);
		stack.getChildren().add(menuArt);
		stack.getChildren().add(vbox);
		layout.setCenter(stack);

		//Event handlers for button clicks
		play.setOnMouseClicked(e -> primaryStage.setScene(scene));
		rules.setOnMouseClicked(e -> primaryStage.setScene(rulesPage));
		back.setOnMouseClicked(e -> primaryStage.setScene(menu));
		scores.setOnMouseClicked(e -> primaryStage.setScene(scorez));
		back2.setOnMouseClicked(e -> primaryStage.setScene(menu));

		//Menu page shown by default
		primaryStage.setScene(menu);
		primaryStage.show();
	}

	/**
	 * Function to get high-score from highscore.dat. Goes through file line by one and sets global highScoreInt
	 * to highest score found. Exception handlers for incorrect lines as well as failing to read file.
	 * Additionally, finds the highest 7 scores and saves them to topSeven string array to display on score page.
	 */
	void getHighScore() {
		//format NAME-SCORE
		int count = 0;
		try{
			BufferedReader reader = new BufferedReader(new FileReader("highscore.dat"));
			String line = reader.readLine();
			while (line != null){
				try{
					count++;
					int checkScore = Integer.parseInt(line.split("-")[1]);
					if (checkScore > highScoreInt){
						highScoreInt = checkScore;
					}
				} catch (NumberFormatException e) {
					System.err.println("Invalid score detected: " + line);
				}
				line = reader.readLine();
			}
			reader.close();
		} catch (IOException ex) {
			System.err.println("Error reading from file");
		}
		String[] scorez = new String[count];
		int i = 0;
		try{
			BufferedReader reader = new BufferedReader(new FileReader("highscore.dat"));
			String line = reader.readLine();
			while (line != null){
				try{
					scorez[i] = line;
					i++;
				} catch (NumberFormatException e) {
					System.err.println("Invalid score detected: " + line);
				}
				line = reader.readLine();
			}
			reader.close();
		} catch (IOException ex) {
			System.err.println("Error reading from file");
		}
		int highest;
		int index = 0;
		for(int z = 0; z < 7; z++){
			highest = 0;
			for(int j = 0; j < count; j++){
				if(highest < Integer.parseInt(scorez[j].split("-")[1])){
					highest = Integer.parseInt(scorez[j].split("-")[1]);
					index = j;
				}
			}
			topSeven[z] = scorez[index];
			scorez[index] = "blank-0";
		}
	}

	/**
	 * Method that takes VBox topScores and fills it with the top seven high-scores to then display it
	 * @param topScores VBox that will contain the high scores
	 */
	private void displayHighScores(VBox topScores){
		topScores.setAlignment(Pos.CENTER);
		for(int i = 0; i < 7; i++){
			Text score = new Text();
			score.setText(topSeven[i]);
			score.setFont(Font.loadFont ("file:src/main/resources/fonts/arcade.ttf", 29));
			score.setFill(javafx.scene.paint.Color.RED);
			topScores.getChildren().add(score);
		}
		topScores.setAlignment(Pos.CENTER);
		topScores.setSpacing(29);
	}

	/**
	 * Function that appends player score to highscore.dat file at any game end (win or lose). Method also asks
	 * player to enter name before saving and will not save score if no name is entered.
	 * @param score player score at game end.
	 */
	private void saveScore(int score){
		//Format: Name-Score
		String enterName = JOptionPane.showInputDialog("Enter name to save score!");
		String symbols = "!@#$%^&*()~?>'<:{}|+_/\".,;'][=-` \\";
		boolean valid = false;

		if(enterName == null){
			valid = true;
		}

		//Do not accept entry while invalid
		while(!valid){
			if (enterName.length() > 10 || symbols.contains(enterName)){
				JOptionPane.showMessageDialog(null, "MAX 8 CHARACTERS & SPECIAL CHARACTERS ARE NOT ALLOWED","Title",JOptionPane.WARNING_MESSAGE);
				enterName = JOptionPane.showInputDialog("Enter name to save score!");
			} else{
				valid = true;
			}
		}

		try{
			BufferedWriter write = new BufferedWriter(new FileWriter("highscore.dat", true));
			write.newLine();
			write.append(enterName).append("-").append(String.valueOf(score));
			write.close();
		} catch (IOException ex2){
			System.err.println("Error writing to file");
		}
	}

	/**
	 * Function that receives the score at game completion and checks it against the current high score. If greater
	 * than high score, sets as new high score. If equal, notifies of tie, keeps original as high score (since it was
	 * accomplished earlier) otherwise, nothing.
	 * @param score current player score
	 */
	void checkScore(int score){
		//Check if current score is greater than/equal to/less than high-score
		if(score > highScoreInt){
			highScoreInt = score;
			highScoreGame = true;
		} else if (score == highScoreInt){
			highScoreGame = false;
		} else {
			highScoreGame = false;
		}
	}

}

